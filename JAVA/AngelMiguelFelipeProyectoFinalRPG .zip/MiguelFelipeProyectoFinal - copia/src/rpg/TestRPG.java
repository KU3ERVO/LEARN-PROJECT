package rpg;

public class TestRPG {

	public static void main(String[] args) {

		new GameManager();

	}

}
