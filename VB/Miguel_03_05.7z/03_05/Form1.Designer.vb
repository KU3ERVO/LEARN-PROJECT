﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btnPressKey = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.btnMouseEnter = New System.Windows.Forms.Button()
        Me.btnMouseMove = New System.Windows.Forms.Button()
        Me.btnInicio = New System.Windows.Forms.Button()
        Me.btnHoverLeave = New System.Windows.Forms.Button()
        Me.btnMouseDown = New System.Windows.Forms.Button()
        Me.btnMouseUp = New System.Windows.Forms.Button()
        Me.btnMouseWheel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 100)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.Location = New System.Drawing.Point(372, 12)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(100, 100)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.Location = New System.Drawing.Point(372, 349)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(100, 100)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btnPressKey
        '
        Me.btnPressKey.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnPressKey.BackColor = System.Drawing.Color.Black
        Me.btnPressKey.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPressKey.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPressKey.Font = New System.Drawing.Font("Nikkyou Sans", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPressKey.ForeColor = System.Drawing.Color.White
        Me.btnPressKey.Location = New System.Drawing.Point(12, 349)
        Me.btnPressKey.Name = "btnPressKey"
        Me.btnPressKey.Size = New System.Drawing.Size(100, 100)
        Me.btnPressKey.TabIndex = 3
        Me.btnPressKey.Text = "KEY"
        Me.btnPressKey.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Button6.Location = New System.Drawing.Point(190, 349)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(100, 100)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "Button6"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Button7.Location = New System.Drawing.Point(190, 12)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(100, 100)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "Button7"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'btnMouseEnter
        '
        Me.btnMouseEnter.BackColor = System.Drawing.Color.Black
        Me.btnMouseEnter.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMouseEnter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMouseEnter.Font = New System.Drawing.Font("Nikkyou Sans", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMouseEnter.ForeColor = System.Drawing.Color.White
        Me.btnMouseEnter.Location = New System.Drawing.Point(12, 12)
        Me.btnMouseEnter.Name = "btnMouseEnter"
        Me.btnMouseEnter.Size = New System.Drawing.Size(100, 100)
        Me.btnMouseEnter.TabIndex = 0
        Me.btnMouseEnter.Text = "ENTER"
        Me.btnMouseEnter.UseVisualStyleBackColor = False
        '
        'btnMouseMove
        '
        Me.btnMouseMove.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnMouseMove.BackColor = System.Drawing.Color.Black
        Me.btnMouseMove.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMouseMove.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMouseMove.Font = New System.Drawing.Font("Nikkyou Sans", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMouseMove.ForeColor = System.Drawing.Color.White
        Me.btnMouseMove.Location = New System.Drawing.Point(372, 12)
        Me.btnMouseMove.Name = "btnMouseMove"
        Me.btnMouseMove.Size = New System.Drawing.Size(100, 100)
        Me.btnMouseMove.TabIndex = 1
        Me.btnMouseMove.Text = "MOVE"
        Me.btnMouseMove.UseVisualStyleBackColor = False
        '
        'btnInicio
        '
        Me.btnInicio.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnInicio.BackColor = System.Drawing.Color.Black
        Me.btnInicio.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnInicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnInicio.Font = New System.Drawing.Font("Nikkyou Sans", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInicio.ForeColor = System.Drawing.Color.White
        Me.btnInicio.Location = New System.Drawing.Point(372, 349)
        Me.btnInicio.Name = "btnInicio"
        Me.btnInicio.Size = New System.Drawing.Size(100, 100)
        Me.btnInicio.TabIndex = 2
        Me.btnInicio.Text = "HOME"
        Me.btnInicio.UseVisualStyleBackColor = False
        '
        'btnHoverLeave
        '
        Me.btnHoverLeave.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnHoverLeave.BackColor = System.Drawing.Color.Black
        Me.btnHoverLeave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnHoverLeave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHoverLeave.Font = New System.Drawing.Font("Nikkyou Sans", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHoverLeave.ForeColor = System.Drawing.Color.White
        Me.btnHoverLeave.Location = New System.Drawing.Point(12, 237)
        Me.btnHoverLeave.Name = "btnHoverLeave"
        Me.btnHoverLeave.Size = New System.Drawing.Size(460, 100)
        Me.btnHoverLeave.TabIndex = 4
        Me.btnHoverLeave.Text = "Hover"
        Me.btnHoverLeave.UseVisualStyleBackColor = False
        '
        'btnMouseDown
        '
        Me.btnMouseDown.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnMouseDown.BackColor = System.Drawing.Color.Black
        Me.btnMouseDown.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMouseDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMouseDown.Font = New System.Drawing.Font("Nikkyou Sans", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMouseDown.ForeColor = System.Drawing.Color.White
        Me.btnMouseDown.Location = New System.Drawing.Point(190, 349)
        Me.btnMouseDown.Name = "btnMouseDown"
        Me.btnMouseDown.Size = New System.Drawing.Size(100, 100)
        Me.btnMouseDown.TabIndex = 5
        Me.btnMouseDown.Text = "DOWN"
        Me.btnMouseDown.UseVisualStyleBackColor = False
        '
        'btnMouseUp
        '
        Me.btnMouseUp.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnMouseUp.BackColor = System.Drawing.Color.Black
        Me.btnMouseUp.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMouseUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMouseUp.Font = New System.Drawing.Font("Nikkyou Sans", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMouseUp.ForeColor = System.Drawing.Color.White
        Me.btnMouseUp.Location = New System.Drawing.Point(190, 12)
        Me.btnMouseUp.Name = "btnMouseUp"
        Me.btnMouseUp.Size = New System.Drawing.Size(100, 100)
        Me.btnMouseUp.TabIndex = 6
        Me.btnMouseUp.Text = "UP"
        Me.btnMouseUp.UseVisualStyleBackColor = False
        '
        'btnMouseWheel
        '
        Me.btnMouseWheel.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnMouseWheel.BackColor = System.Drawing.Color.Black
        Me.btnMouseWheel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMouseWheel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnMouseWheel.Font = New System.Drawing.Font("Nikkyou Sans", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMouseWheel.ForeColor = System.Drawing.Color.White
        Me.btnMouseWheel.Location = New System.Drawing.Point(12, 125)
        Me.btnMouseWheel.Name = "btnMouseWheel"
        Me.btnMouseWheel.Size = New System.Drawing.Size(460, 100)
        Me.btnMouseWheel.TabIndex = 7
        Me.btnMouseWheel.Text = "WHEEL"
        Me.btnMouseWheel.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(484, 461)
        Me.Controls.Add(Me.btnMouseWheel)
        Me.Controls.Add(Me.btnMouseUp)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.btnMouseDown)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.btnHoverLeave)
        Me.Controls.Add(Me.btnPressKey)
        Me.Controls.Add(Me.btnInicio)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.btnMouseMove)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnMouseEnter)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents btnPressKey As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents btnMouseEnter As Button
    Friend WithEvents btnMouseMove As Button
    Friend WithEvents btnInicio As Button
    Friend WithEvents btnHoverLeave As Button
    Friend WithEvents btnMouseDown As Button
    Friend WithEvents btnMouseUp As Button
    Friend WithEvents btnMouseWheel As Button
End Class
