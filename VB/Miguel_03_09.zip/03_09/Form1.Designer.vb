﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnBorrarDerecha = New System.Windows.Forms.Button()
        Me.btn0 = New System.Windows.Forms.Button()
        Me.btnMasMenos = New System.Windows.Forms.Button()
        Me.btnIgual = New System.Windows.Forms.Button()
        Me.btnMulti = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btnSuma = New System.Windows.Forms.Button()
        Me.btnPotencia = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.btnResta = New System.Windows.Forms.Button()
        Me.btnPorcentaje = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btnDivision = New System.Windows.Forms.Button()
        Me.btnInversa = New System.Windows.Forms.Button()
        Me.btnBorrarTodo = New System.Windows.Forms.Button()
        Me.btnPunto = New System.Windows.Forms.Button()
        Me.btnRaiz = New System.Windows.Forms.Button()
        Me.txtResultado = New System.Windows.Forms.RichTextBox()
        Me.SuspendLayout()
        '
        'btnBorrarDerecha
        '
        Me.btnBorrarDerecha.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnBorrarDerecha.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBorrarDerecha.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBorrarDerecha.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBorrarDerecha.ForeColor = System.Drawing.Color.White
        Me.btnBorrarDerecha.Location = New System.Drawing.Point(22, 125)
        Me.btnBorrarDerecha.Name = "btnBorrarDerecha"
        Me.btnBorrarDerecha.Size = New System.Drawing.Size(75, 75)
        Me.btnBorrarDerecha.TabIndex = 1
        Me.btnBorrarDerecha.Text = "BC"
        Me.btnBorrarDerecha.UseVisualStyleBackColor = False
        '
        'btn0
        '
        Me.btn0.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btn0.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn0.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn0.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn0.ForeColor = System.Drawing.Color.White
        Me.btn0.Location = New System.Drawing.Point(103, 125)
        Me.btn0.Name = "btn0"
        Me.btn0.Size = New System.Drawing.Size(75, 75)
        Me.btn0.TabIndex = 2
        Me.btn0.Text = "0"
        Me.btn0.UseVisualStyleBackColor = False
        '
        'btnMasMenos
        '
        Me.btnMasMenos.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnMasMenos.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMasMenos.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMasMenos.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMasMenos.ForeColor = System.Drawing.Color.White
        Me.btnMasMenos.Location = New System.Drawing.Point(184, 125)
        Me.btnMasMenos.Name = "btnMasMenos"
        Me.btnMasMenos.Size = New System.Drawing.Size(75, 75)
        Me.btnMasMenos.TabIndex = 3
        Me.btnMasMenos.Text = "+/-"
        Me.btnMasMenos.UseVisualStyleBackColor = False
        '
        'btnIgual
        '
        Me.btnIgual.BackColor = System.Drawing.Color.Maroon
        Me.btnIgual.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnIgual.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnIgual.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnIgual.ForeColor = System.Drawing.Color.White
        Me.btnIgual.Location = New System.Drawing.Point(265, 125)
        Me.btnIgual.Name = "btnIgual"
        Me.btnIgual.Size = New System.Drawing.Size(155, 75)
        Me.btnIgual.TabIndex = 4
        Me.btnIgual.Text = "="
        Me.btnIgual.UseVisualStyleBackColor = False
        '
        'btnMulti
        '
        Me.btnMulti.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnMulti.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMulti.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMulti.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMulti.ForeColor = System.Drawing.Color.White
        Me.btnMulti.Location = New System.Drawing.Point(265, 449)
        Me.btnMulti.Name = "btnMulti"
        Me.btnMulti.Size = New System.Drawing.Size(75, 75)
        Me.btnMulti.TabIndex = 5
        Me.btnMulti.Text = "*"
        Me.btnMulti.UseVisualStyleBackColor = False
        '
        'btn1
        '
        Me.btn1.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btn1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn1.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1.ForeColor = System.Drawing.Color.White
        Me.btn1.Location = New System.Drawing.Point(22, 206)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(75, 75)
        Me.btn1.TabIndex = 6
        Me.btn1.Text = "1"
        Me.btn1.UseVisualStyleBackColor = False
        '
        'btn2
        '
        Me.btn2.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btn2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn2.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn2.ForeColor = System.Drawing.Color.White
        Me.btn2.Location = New System.Drawing.Point(103, 206)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(75, 75)
        Me.btn2.TabIndex = 7
        Me.btn2.Text = "2"
        Me.btn2.UseVisualStyleBackColor = False
        '
        'btn3
        '
        Me.btn3.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btn3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn3.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn3.ForeColor = System.Drawing.Color.White
        Me.btn3.Location = New System.Drawing.Point(184, 206)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(75, 75)
        Me.btn3.TabIndex = 8
        Me.btn3.Text = "3"
        Me.btn3.UseVisualStyleBackColor = False
        '
        'btnSuma
        '
        Me.btnSuma.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnSuma.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSuma.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSuma.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSuma.ForeColor = System.Drawing.Color.White
        Me.btnSuma.Location = New System.Drawing.Point(265, 206)
        Me.btnSuma.Name = "btnSuma"
        Me.btnSuma.Size = New System.Drawing.Size(75, 75)
        Me.btnSuma.TabIndex = 9
        Me.btnSuma.Text = "+"
        Me.btnSuma.UseVisualStyleBackColor = False
        '
        'btnPotencia
        '
        Me.btnPotencia.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnPotencia.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPotencia.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPotencia.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPotencia.ForeColor = System.Drawing.Color.White
        Me.btnPotencia.Location = New System.Drawing.Point(346, 206)
        Me.btnPotencia.Name = "btnPotencia"
        Me.btnPotencia.Size = New System.Drawing.Size(75, 75)
        Me.btnPotencia.TabIndex = 10
        Me.btnPotencia.Text = "^"
        Me.btnPotencia.UseVisualStyleBackColor = False
        '
        'btn4
        '
        Me.btn4.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btn4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn4.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn4.ForeColor = System.Drawing.Color.White
        Me.btn4.Location = New System.Drawing.Point(22, 287)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(75, 75)
        Me.btn4.TabIndex = 11
        Me.btn4.Text = "4"
        Me.btn4.UseVisualStyleBackColor = False
        '
        'btn5
        '
        Me.btn5.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btn5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn5.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn5.ForeColor = System.Drawing.Color.White
        Me.btn5.Location = New System.Drawing.Point(103, 287)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(75, 75)
        Me.btn5.TabIndex = 12
        Me.btn5.Text = "5"
        Me.btn5.UseVisualStyleBackColor = False
        '
        'btn6
        '
        Me.btn6.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btn6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn6.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn6.ForeColor = System.Drawing.Color.White
        Me.btn6.Location = New System.Drawing.Point(184, 287)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(75, 75)
        Me.btn6.TabIndex = 13
        Me.btn6.Text = "6"
        Me.btn6.UseVisualStyleBackColor = False
        '
        'btnResta
        '
        Me.btnResta.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnResta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnResta.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnResta.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResta.ForeColor = System.Drawing.Color.White
        Me.btnResta.Location = New System.Drawing.Point(265, 287)
        Me.btnResta.Name = "btnResta"
        Me.btnResta.Size = New System.Drawing.Size(75, 75)
        Me.btnResta.TabIndex = 14
        Me.btnResta.Text = "-"
        Me.btnResta.UseVisualStyleBackColor = False
        '
        'btnPorcentaje
        '
        Me.btnPorcentaje.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnPorcentaje.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPorcentaje.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPorcentaje.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPorcentaje.ForeColor = System.Drawing.Color.White
        Me.btnPorcentaje.Location = New System.Drawing.Point(346, 287)
        Me.btnPorcentaje.Name = "btnPorcentaje"
        Me.btnPorcentaje.Size = New System.Drawing.Size(75, 75)
        Me.btnPorcentaje.TabIndex = 15
        Me.btnPorcentaje.Text = "%"
        Me.btnPorcentaje.UseVisualStyleBackColor = False
        '
        'btn7
        '
        Me.btn7.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btn7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn7.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn7.ForeColor = System.Drawing.Color.White
        Me.btn7.Location = New System.Drawing.Point(22, 368)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(75, 75)
        Me.btn7.TabIndex = 16
        Me.btn7.Text = "7"
        Me.btn7.UseVisualStyleBackColor = False
        '
        'btn8
        '
        Me.btn8.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btn8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn8.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn8.ForeColor = System.Drawing.Color.White
        Me.btn8.Location = New System.Drawing.Point(103, 368)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(75, 75)
        Me.btn8.TabIndex = 17
        Me.btn8.Text = "8"
        Me.btn8.UseVisualStyleBackColor = False
        '
        'btn9
        '
        Me.btn9.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btn9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn9.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn9.ForeColor = System.Drawing.Color.White
        Me.btn9.Location = New System.Drawing.Point(184, 368)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(75, 75)
        Me.btn9.TabIndex = 18
        Me.btn9.Text = "9"
        Me.btn9.UseVisualStyleBackColor = False
        '
        'btnDivision
        '
        Me.btnDivision.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnDivision.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDivision.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnDivision.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDivision.ForeColor = System.Drawing.Color.White
        Me.btnDivision.Location = New System.Drawing.Point(265, 368)
        Me.btnDivision.Name = "btnDivision"
        Me.btnDivision.Size = New System.Drawing.Size(75, 75)
        Me.btnDivision.TabIndex = 19
        Me.btnDivision.Text = "/"
        Me.btnDivision.UseVisualStyleBackColor = False
        '
        'btnInversa
        '
        Me.btnInversa.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnInversa.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnInversa.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnInversa.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInversa.ForeColor = System.Drawing.Color.White
        Me.btnInversa.Location = New System.Drawing.Point(346, 449)
        Me.btnInversa.Name = "btnInversa"
        Me.btnInversa.Size = New System.Drawing.Size(75, 75)
        Me.btnInversa.TabIndex = 20
        Me.btnInversa.Text = "1/x"
        Me.btnInversa.UseVisualStyleBackColor = False
        '
        'btnBorrarTodo
        '
        Me.btnBorrarTodo.BackColor = System.Drawing.Color.Maroon
        Me.btnBorrarTodo.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBorrarTodo.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnBorrarTodo.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBorrarTodo.ForeColor = System.Drawing.Color.White
        Me.btnBorrarTodo.Location = New System.Drawing.Point(22, 449)
        Me.btnBorrarTodo.Name = "btnBorrarTodo"
        Me.btnBorrarTodo.Size = New System.Drawing.Size(156, 75)
        Me.btnBorrarTodo.TabIndex = 21
        Me.btnBorrarTodo.Text = "CE"
        Me.btnBorrarTodo.UseVisualStyleBackColor = False
        '
        'btnPunto
        '
        Me.btnPunto.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnPunto.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPunto.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPunto.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPunto.ForeColor = System.Drawing.Color.White
        Me.btnPunto.Location = New System.Drawing.Point(184, 449)
        Me.btnPunto.Name = "btnPunto"
        Me.btnPunto.Size = New System.Drawing.Size(75, 75)
        Me.btnPunto.TabIndex = 22
        Me.btnPunto.Text = "."
        Me.btnPunto.UseVisualStyleBackColor = False
        '
        'btnRaiz
        '
        Me.btnRaiz.BackColor = System.Drawing.Color.FromArgb(CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer), CType(CType(76, Byte), Integer))
        Me.btnRaiz.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRaiz.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnRaiz.Font = New System.Drawing.Font("Bahnschrift SemiBold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRaiz.ForeColor = System.Drawing.Color.White
        Me.btnRaiz.Location = New System.Drawing.Point(346, 368)
        Me.btnRaiz.Name = "btnRaiz"
        Me.btnRaiz.Size = New System.Drawing.Size(75, 75)
        Me.btnRaiz.TabIndex = 23
        Me.btnRaiz.Text = "√"
        Me.btnRaiz.UseVisualStyleBackColor = False
        '
        'txtResultado
        '
        Me.txtResultado.BackColor = System.Drawing.Color.FromArgb(CType(CType(108, Byte), Integer), CType(CType(108, Byte), Integer), CType(CType(108, Byte), Integer))
        Me.txtResultado.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtResultado.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtResultado.ForeColor = System.Drawing.Color.White
        Me.txtResultado.Location = New System.Drawing.Point(21, 12)
        Me.txtResultado.Name = "txtResultado"
        Me.txtResultado.Size = New System.Drawing.Size(399, 75)
        Me.txtResultado.TabIndex = 24
        Me.txtResultado.Text = " 0"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(57, Byte), Integer), CType(CType(57, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(437, 566)
        Me.Controls.Add(Me.txtResultado)
        Me.Controls.Add(Me.btnRaiz)
        Me.Controls.Add(Me.btnPunto)
        Me.Controls.Add(Me.btnBorrarTodo)
        Me.Controls.Add(Me.btnInversa)
        Me.Controls.Add(Me.btnDivision)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.btn8)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btnPorcentaje)
        Me.Controls.Add(Me.btnResta)
        Me.Controls.Add(Me.btn6)
        Me.Controls.Add(Me.btn5)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btnPotencia)
        Me.Controls.Add(Me.btnSuma)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.btnMulti)
        Me.Controls.Add(Me.btnIgual)
        Me.Controls.Add(Me.btnMasMenos)
        Me.Controls.Add(Me.btn0)
        Me.Controls.Add(Me.btnBorrarDerecha)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnBorrarDerecha As Button
    Friend WithEvents btn0 As Button
    Friend WithEvents btnMasMenos As Button
    Friend WithEvents btnIgual As Button
    Friend WithEvents btnMulti As Button
    Friend WithEvents btn1 As Button
    Friend WithEvents btn2 As Button
    Friend WithEvents btn3 As Button
    Friend WithEvents btnSuma As Button
    Friend WithEvents btnPotencia As Button
    Friend WithEvents btn4 As Button
    Friend WithEvents btn5 As Button
    Friend WithEvents btn6 As Button
    Friend WithEvents btnResta As Button
    Friend WithEvents btnPorcentaje As Button
    Friend WithEvents btn7 As Button
    Friend WithEvents btn8 As Button
    Friend WithEvents btn9 As Button
    Friend WithEvents btnDivision As Button
    Friend WithEvents btnInversa As Button
    Friend WithEvents btnBorrarTodo As Button
    Friend WithEvents btnPunto As Button
    Friend WithEvents btnRaiz As Button
    Friend WithEvents txtResultado As RichTextBox
End Class
