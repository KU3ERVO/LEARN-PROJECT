﻿Imports System.IO
Imports System.Runtime.CompilerServices

Public Class Form1
    Private Sub btnReserva_Click(sender As Object, e As EventArgs) Handles btnReserva.Click
        FormEvento.Show()
        Me.Hide()
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        End
    End Sub
End Class
