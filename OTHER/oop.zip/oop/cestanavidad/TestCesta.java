package oop.cestanavidad;

import oop.cestanavidad.Producto.Productos;

public class TestCesta {
	
	Cliente c1 = new Cliente("Mary","Scots","00000001S","empresa");
	
	Productos i = Producto.Productos.MAZAPAN;

}
