package oop.cestanavidad;

public class Producto {
	
	enum Productos{JAMON,FOIE,TURRON,MAZAPAN,SIDRA,CAVA}
	
	Productos productos;

	public void Elige() {
		
		switch(productos) {
		
		case JAMON:
		}
	}
	
	
}
