package oop.pajaro;

public class TestPajaro {

	public static void main(String[] args) {
		
		Pajaro p1 = new Pajaro();
		System.out.println(p1.toString());
		Pajaro p2 = new Pajaro();
		System.out.println(p2.toString());
		Pajaro p3 = new Pajaro();
		System.out.println(p3.toString());
		Pajaro p4 = new Pajaro();
		System.out.println(p4.toString());
		Pajaro p5 = new Pajaro();
		System.out.println(p5.toString());

	}

}
