package oop.cestanavidad;

public enum TipoProducto {DULCE,SALADO,BEBIDA
}
