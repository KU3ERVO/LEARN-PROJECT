package oop.cestanavidad;

public enum TipoOrg {PARTICULAR,EMPRESA
}
